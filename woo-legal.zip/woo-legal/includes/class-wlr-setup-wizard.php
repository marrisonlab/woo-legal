<?php
/**
 * Wizard di configurazione iniziale del plugin.
 *
 * Accessibile da WooCommerce → Resi UE → Configurazione.
 * Può essere rieseguito in qualsiasi momento.
 *
 * @package Woo_Legal_Returns
 */

defined( 'ABSPATH' ) || exit;

class WLR_Setup_Wizard {

	const OPTION_KEY  = 'wlr_setup_options';
	const WIZARD_SLUG = 'wlr-setup-wizard';

	private static ?WLR_Setup_Wizard $instance = null;

	/** Passi del wizard: slug => etichetta. */
	private array $steps = array(
		'precontractual'  => 'Informativa precontrattuale',
		'menu'            => 'Menu di navigazione',
		'checkout_notice' => 'Avviso al checkout',
		'complete'        => 'Completato',
	);

	public static function instance(): self {
		if ( null === self::$instance ) {
			self::$instance = new self();
			self::$instance->hooks();
		}
		return self::$instance;
	}

	private function hooks(): void {
		add_shortcode( 'wlr_precontractual_policy', array( $this, 'render_policy_shortcode' ) );
		if ( is_admin() ) {
			add_action( 'admin_menu', array( $this, 'register_page' ) );
			add_action( 'admin_init', array( $this, 'handle_post' ) );
			add_action( 'admin_notices', array( $this, 'show_setup_notice' ) );
		}
	}

	public function render_policy_shortcode(): string {
		// The shared page template contains editor markers, not presentation for the shortcode.
		$content = preg_replace( '/<!-- \/?wp:[^>]*-->\s*/', '', $this->get_default_page_content() );
		return do_shortcode( $content );
	}

	// -------------------------------------------------------------------------
	// Registrazione menu
	// -------------------------------------------------------------------------

	public function register_page(): void {
		add_submenu_page(
			null,
			__( 'Configurazione Woo Legal Returns', 'woo-legal-returns' ),
			'',
			'manage_options',
			self::WIZARD_SLUG,
			array( $this, 'render' )
		);
	}

	// -------------------------------------------------------------------------
	// Gestione POST
	// -------------------------------------------------------------------------

	public function handle_post(): void {
		if ( empty( $_POST['wlr_wizard_step'] ) ) {
			return;
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Permessi insufficienti.', 'woo-legal-returns' ) );
		}

		$step = sanitize_key( wp_unslash( $_POST['wlr_wizard_step'] ) );
		check_admin_referer( 'wlr_wizard_' . $step );

		try {
			match ( $step ) {
				'precontractual'  => $this->save_precontractual(),
				'menu'            => $this->save_menu(),
				'checkout_notice' => $this->save_checkout_notice(),
				default           => null,
			};
		} catch ( \Throwable $e ) {
			$this->log_error( 'Wizard step "' . $step . '" error: ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine() );
			wp_die(
				esc_html__( 'Si è verificato un errore durante il salvataggio della configurazione. Riprova o controlla il debug.log del server.', 'woo-legal-returns' ),
				esc_html__( 'Errore configurazione', 'woo-legal-returns' ),
				array( 'back_link' => true )
			);
		}
	}

	private function save_precontractual(): void {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Verified in handle_post before dispatch.
		$mode        = sanitize_key( wp_unslash( $_POST['page_mode'] ?? 'new' ) );
		$trader_data = $this->sanitize_trader_data_from_post();
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		if ( ! in_array( $mode, array( 'new', 'existing', 'shortcode' ), true ) ) {
			wp_die( esc_html__( 'Seleziona una modalità valida per l’informativa.', 'woo-legal-returns' ) );
		}

		if ( 'shortcode' === $mode ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Verified in handle_post before dispatch.
			$page_id = absint( wp_unslash( $_POST['shortcode_page_id'] ?? 0 ) );
			$page    = $page_id ? get_post( $page_id ) : null;
			if ( $page_id && ( ! $page || 'page' !== $page->post_type || 'publish' !== $page->post_status || ! current_user_can( 'edit_post', $page_id ) ) ) {
				wp_die( esc_html__( 'Seleziona una pagina pubblicata e modificabile per lo shortcode.', 'woo-legal-returns' ) );
			}
			$this->save_trader_data( $trader_data );
			$this->save_option( 'precontractual_mode', 'shortcode' );
			$this->save_option( 'precontractual_page_id', $page_id );
			wp_safe_redirect( $this->wizard_url( 'menu' ) );
			exit;
		}

		if ( 'existing' === $mode ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Verified in handle_post before dispatch.
			$page_id = absint( wp_unslash( $_POST['existing_page_id'] ?? 0 ) );
			$page    = $page_id ? get_post( $page_id ) : null;
			if ( ! $page || 'page' !== $page->post_type || ! current_user_can( 'edit_post', $page_id ) ) {
				wp_die( esc_html__( 'Seleziona una pagina valida e modificabile.', 'woo-legal-returns' ) );
			}
			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Verified in handle_post before dispatch.
			$refresh_existing_page = ! empty( $_POST['refresh_existing_page'] );
			if ( $page_id && $refresh_existing_page ) {
				$updated = wp_update_post(
					array(
						'ID'           => $page_id,
						'post_content' => $this->get_default_page_content( $trader_data ),
					),
					true
				);
				if ( ! $updated || is_wp_error( $updated ) ) {
					wp_die( esc_html__( 'Aggiornamento della pagina fallito.', 'woo-legal-returns' ) );
				}
			}
		} else {
			// phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Verified in handle_post before dispatch; unslashed here and sanitized below.
			$raw_title = wp_unslash( $_POST['new_page_title'] ?? __( 'Informativa sul Diritto di Recesso', 'woo-legal-returns' ) );
			$title     = sanitize_text_field( $raw_title );
			$page_id   = wp_insert_post(
				array(
					'post_title'   => $title,
					'post_content' => $this->get_default_page_content( $trader_data ),
					'post_status'  => 'publish',
					'post_type'    => 'page',
				),
				true
			);
			if ( $page_id && ! is_wp_error( $page_id ) ) {
				update_post_meta( (int) $page_id, '_wlr_generated_precontractual_page', '1' );
			}
		}

		if ( $page_id && ! is_wp_error( $page_id ) ) {
			$this->save_trader_data( $trader_data );
			$this->save_option( 'precontractual_mode', $mode );
			$this->save_option( 'precontractual_page_id', (int) $page_id );
		} else {
			wp_die( esc_html__( 'Creazione della pagina fallita.', 'woo-legal-returns' ) );
		}

		wp_safe_redirect( $this->wizard_url( 'menu' ) );
		exit;
	}

	private function save_menu(): void {
		$page_id = (int) $this->get_option( 'precontractual_page_id' );
		if ( ! $page_id ) {
			wp_safe_redirect( $this->wizard_url( 'checkout_notice' ) );
			exit;
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Verified in handle_post before dispatch.
		$menu_ids = array_map( 'absint', (array) wp_unslash( $_POST['menus'] ?? array() ) );
		$added    = array();

		foreach ( $menu_ids as $menu_id ) {
			if ( ! $menu_id ) {
				continue;
			}

			// Evita duplicati: non aggiungere se il link è già presente.
			if ( $page_id ) {
				$existing_items = wp_get_nav_menu_items( $menu_id, array( 'nopaging' => true ) );
				$existing       = $existing_items ? $existing_items : array();
				foreach ( $existing as $nav_item ) {
					if ( 'post_type' === $nav_item->type && (int) $nav_item->object_id === $page_id ) {
						$added[] = $menu_id;
						continue 2;
					}
				}
			}

			$item_id = wp_update_nav_menu_item(
				$menu_id,
				0,
				array(
					'menu-item-title'     => $page_id
						? get_the_title( $page_id )
						: __( 'Informativa Recesso', 'woo-legal-returns' ),
					'menu-item-object'    => 'page',
					'menu-item-object-id' => $page_id,
					'menu-item-type'      => 'post_type',
					'menu-item-status'    => 'publish',
				)
			);
			if ( $item_id && ! is_wp_error( $item_id ) ) {
				$added[] = $menu_id;
			}
		}

		$this->save_option( 'menu_ids', $added );

		wp_safe_redirect( $this->wizard_url( 'checkout_notice' ) );
		exit;
	}

	// -------------------------------------------------------------------------
	// Rendering
	// -------------------------------------------------------------------------

	public function render(): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only wizard step routing.
		$step = isset( $_GET['step'] ) ? sanitize_key( wp_unslash( $_GET['step'] ) ) : 'precontractual';
		if ( ! array_key_exists( $step, $this->steps ) ) {
			$step = 'precontractual';
		}

		$this->render_styles();
		?>
		<div class="wrap wlr-wizard">
			<h1 class="wlr-wizard-title">
				<?php esc_html_e( 'Configurazione guidata – Woo Legal Returns', 'woo-legal-returns' ); ?>
			</h1>
			<?php $this->render_step_indicator( $step ); ?>
			<div class="wlr-wizard-card">
				<?php
				switch ( $step ) {
					case 'menu':
						$this->render_step_menu();
						break;
					case 'checkout_notice':
						$this->render_step_checkout_notice();
						break;
					case 'complete':
						$this->render_step_complete();
						break;
					default:
						$this->render_step_precontractual();
				}
				?>
			</div>
		</div>
		<?php
	}

	private function render_step_indicator( string $current ): void {
		$order = array_keys( $this->steps );
		$pos   = (int) array_search( $current, $order, true );
		echo '<ol class="wlr-wizard-steps">';
		foreach ( $this->steps as $slug => $label ) {
			$idx = (int) array_search( $slug, $order, true );
			if ( $idx < $pos ) {
				$cls = 'done';
			} elseif ( $idx === $pos ) {
				$cls = 'active';
			} else {
				$cls = '';
			}
			echo '<li class="' . esc_attr( $cls ) . '">' . esc_html( $label ) . '</li>';
		}
		echo '</ol>';
	}

	private function render_step_precontractual(): void {
		$saved_id          = (int) $this->get_option( 'precontractual_page_id' );
		$mode              = 'shortcode' === $this->get_option( 'precontractual_mode' ) ? 'shortcode' : ( $saved_id ? 'existing' : 'new' );
		$is_generated_page = $saved_id && '1' === get_post_meta( $saved_id, '_wlr_generated_precontractual_page', true );
		$trader_data       = $this->get_trader_data();
		$pages             = get_pages(
			array(
				'post_status' => 'publish',
				'sort_column' => 'post_title',
			)
		);
		?>
		<h2><?php esc_html_e( 'Pagina Informativa Precontrattuale', 'woo-legal-returns' ); ?></h2>
		<p class="wlr-step-desc">
			<?php esc_html_e( 'Scegli se creare la pagina dell’informativa sul diritto di recesso oppure inserire lo shortcode in una pagina realizzata da te, anche con Elementor. Il testo usa paragrafi, grassetto, elenchi e corsivo, senza titoli H1–H6.', 'woo-legal-returns' ); ?>
		</p>

		<form method="post">
			<?php wp_nonce_field( 'wlr_wizard_precontractual' ); ?>
			<input type="hidden" name="wlr_wizard_step" value="precontractual">

			<div class="wlr-radio-group">
				<label class="wlr-radio-label">
					<input type="radio" name="page_mode" value="new" <?php checked( $mode, 'new' ); ?>>
					<span>
						<strong><?php esc_html_e( 'Crea una nuova pagina', 'woo-legal-returns' ); ?></strong><br>
						<small><?php esc_html_e( 'Il contenuto verrà precompilato con il testo standard D.Lgs. 209/2025', 'woo-legal-returns' ); ?></small>
					</span>
				</label>
				<div class="wlr-sub-fields" id="wlr-new-fields">
					<label for="wlr_new_page_title"><?php esc_html_e( 'Titolo pagina', 'woo-legal-returns' ); ?></label>
					<input type="text" id="wlr_new_page_title" name="new_page_title" class="regular-text"
						value="<?php echo esc_attr( __( 'Informativa sul Diritto di Recesso', 'woo-legal-returns' ) ); ?>">
				</div>

				<label class="wlr-radio-label">
					<input type="radio" name="page_mode" value="shortcode" <?php checked( $mode, 'shortcode' ); ?>>
					<span>
						<strong><?php esc_html_e( 'Genera lo shortcode per una mia pagina', 'woo-legal-returns' ); ?></strong><br>
						<small><?php esc_html_e( 'Il testo si aggiorna dai dati venditore salvati, senza creare o modificare pagine.', 'woo-legal-returns' ); ?></small>
					</span>
				</label>
				<div class="wlr-sub-fields" id="wlr-shortcode-fields">
					<?php $this->render_policy_shortcode_instructions(); ?>
					<label for="wlr_shortcode_page_id"><?php esc_html_e( 'Pagina che conterrà lo shortcode (facoltativa)', 'woo-legal-returns' ); ?></label>
					<select id="wlr_shortcode_page_id" name="shortcode_page_id">
						<option value="0"><?php esc_html_e( '— La assocerò in seguito —', 'woo-legal-returns' ); ?></option>
						<?php foreach ( $pages as $p ) : ?>
						<option value="<?php echo esc_attr( $p->ID ); ?>" <?php selected( $saved_id, $p->ID ); ?>><?php echo esc_html( $p->post_title ); ?></option>
						<?php endforeach; ?>
					</select>
					<p class="description"><?php esc_html_e( 'La pagina associata viene usata per i link dell’informativa e per i menu. Inserisci tu lo shortcode nel punto desiderato, poi pubblica la pagina e associala qui.', 'woo-legal-returns' ); ?></p>
				</div>

				<label class="wlr-radio-label">
					<input type="radio" name="page_mode" value="existing" <?php checked( $mode, 'existing' ); ?>>
					<span>
						<strong><?php esc_html_e( 'Usa una pagina già esistente', 'woo-legal-returns' ); ?></strong><br>
						<small><?php esc_html_e( 'Seleziona una pagina già presente nel sito', 'woo-legal-returns' ); ?></small>
					</span>
				</label>
				<div class="wlr-sub-fields" id="wlr-existing-fields">
					<select name="existing_page_id">
						<option value=""><?php esc_html_e( '— Seleziona una pagina —', 'woo-legal-returns' ); ?></option>
						<?php foreach ( $pages as $p ) : ?>
						<option value="<?php echo esc_attr( $p->ID ); ?>" <?php selected( $saved_id, $p->ID ); ?>>
							<?php echo esc_html( $p->post_title ); ?>
						</option>
						<?php endforeach; ?>
					</select>
					<p>
						<label>
							<input type="checkbox" name="refresh_existing_page" value="1" <?php checked( $is_generated_page && 'shortcode' !== $mode ); ?>>
							<?php esc_html_e( 'Aggiorna il contenuto della pagina selezionata con i dati venditore inseriti qui sotto', 'woo-legal-returns' ); ?>
						</label>
					</p>
				</div>
			</div>

			<h3><?php esc_html_e( 'Dati venditore da inserire nell\'informativa', 'woo-legal-returns' ); ?></h3>
			<p class="description">
				<?php esc_html_e( 'Questi campi vengono precompilati dai dati WooCommerce quando disponibili. Sono usati sia per la pagina generata sia per lo shortcode.', 'woo-legal-returns' ); ?>
			</p>

			<table class="form-table wlr-trader-fields" role="presentation">
				<tr>
					<th scope="row"><label for="wlr_trader_name"><?php esc_html_e( 'Nome venditore', 'woo-legal-returns' ); ?></label></th>
					<td>
						<input type="text" id="wlr_trader_name" name="trader_name" class="regular-text"
							value="<?php echo esc_attr( $trader_data['name'] ); ?>">
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="wlr_trader_address"><?php esc_html_e( 'Indirizzo sede', 'woo-legal-returns' ); ?></label></th>
					<td>
						<textarea id="wlr_trader_address" name="trader_address" rows="3" class="large-text"><?php echo esc_textarea( $trader_data['address'] ); ?></textarea>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="wlr_trader_email"><?php esc_html_e( 'Email assistenza', 'woo-legal-returns' ); ?></label></th>
					<td>
						<input type="email" id="wlr_trader_email" name="trader_email" class="regular-text"
							value="<?php echo esc_attr( $trader_data['email'] ); ?>">
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="wlr_trader_phone"><?php esc_html_e( 'Telefono negozio', 'woo-legal-returns' ); ?></label></th>
					<td>
						<input type="text" id="wlr_trader_phone" name="trader_phone" class="regular-text"
							value="<?php echo esc_attr( $trader_data['phone'] ); ?>">
						<p class="description"><?php esc_html_e( 'WooCommerce non ha un campo telefono negozio standard: se lo compili, verra inserito nell\'informativa.', 'woo-legal-returns' ); ?></p>
					</td>
				</tr>
			</table>

			<div class="wlr-wizard-actions">
				<div></div>
				<div class="wlr-actions-right">
					<a href="<?php echo esc_url( $this->wizard_url( 'menu' ) ); ?>" class="wlr-skip">
						<?php esc_html_e( 'Salta questo passaggio', 'woo-legal-returns' ); ?>
					</a>
					<button type="submit" class="button button-primary button-large">
						<?php esc_html_e( 'Avanti →', 'woo-legal-returns' ); ?>
					</button>
				</div>
			</div>
		</form>

		<script>
		(function () {
			var radios   = document.querySelectorAll('[name="page_mode"]');
			var newDiv   = document.getElementById('wlr-new-fields');
			var existDiv = document.getElementById('wlr-existing-fields');
			var shortcodeDiv = document.getElementById('wlr-shortcode-fields');
			function sync() {
				var v = document.querySelector('[name="page_mode"]:checked').value;
				newDiv.style.display   = ( v === 'new' )      ? '' : 'none';
				existDiv.style.display = ( v === 'existing' ) ? '' : 'none';
				shortcodeDiv.style.display = ( v === 'shortcode' ) ? '' : 'none';
			}
			radios.forEach( function (r) { r.addEventListener( 'change', sync ); } );
			sync();
		}());
		</script>
		<?php
	}

	private function render_step_menu(): void {
		$saved_ids = (array) $this->get_option( 'menu_ids', array() );
		$nav_menus = wp_get_nav_menus();
		$page_id   = (int) $this->get_option( 'precontractual_page_id' );
		?>
		<h2><?php esc_html_e( 'Menu di Navigazione', 'woo-legal-returns' ); ?></h2>
		<?php if ( 'shortcode' === $this->get_option( 'precontractual_mode' ) ) : ?>
			<?php $this->render_policy_shortcode_instructions(); ?>
		<?php endif; ?>
		<p class="wlr-step-desc">
			<?php esc_html_e( 'Seleziona i menu in cui aggiungere il link alla pagina dell\'informativa. Puoi saltare e farlo manualmente da Aspetto → Menu.', 'woo-legal-returns' ); ?>
		</p>

		<?php if ( $page_id ) : ?>
		<div class="wlr-info-box">
			<?php
			printf(
				/* translators: %s: nome pagina con link */
				esc_html__( 'Pagina configurata: %s', 'woo-legal-returns' ),
				'<strong><a href="' . esc_url( get_edit_post_link( $page_id ) ) . '" target="_blank">'
					. esc_html( get_the_title( $page_id ) ) . '</a></strong>'
			);
			?>
		</div>
		<?php else : ?>
		<p class="description"><?php esc_html_e( 'Nessuna pagina informativa associata. Puoi proseguire e tornare al primo passaggio dopo aver pubblicato la tua pagina con lo shortcode.', 'woo-legal-returns' ); ?></p>
		<?php endif; ?>

		<form method="post">
			<?php wp_nonce_field( 'wlr_wizard_menu' ); ?>
			<input type="hidden" name="wlr_wizard_step" value="menu">

			<?php if ( $page_id && $nav_menus ) : ?>
				<div class="wlr-checkbox-group">
				<?php foreach ( $nav_menus as $menu ) : ?>
					<label class="wlr-checkbox-label">
						<input type="checkbox" name="menus[]"
							value="<?php echo esc_attr( $menu->term_id ); ?>"
							<?php checked( in_array( $menu->term_id, $saved_ids, true ) ); ?>>
						<span>
							<?php echo esc_html( $menu->name ); ?>
							<small style="color:#a7aaad;">
								(
								<?php
								printf(
									/* translators: %d: numero voci menu */
									esc_html__( '%d voci', 'woo-legal-returns' ),
									absint( $menu->count )
								);
								?>
									)
							</small>
						</span>
					</label>
				<?php endforeach; ?>
				</div>
			<?php elseif ( $page_id ) : ?>
				<p class="description">
					<?php esc_html_e( 'Nessun menu trovato. Crea prima un menu da Aspetto → Menu, poi riesegui la configurazione.', 'woo-legal-returns' ); ?>
				</p>
			<?php endif; ?>

			<div class="wlr-wizard-actions">
				<a href="<?php echo esc_url( $this->wizard_url( 'precontractual' ) ); ?>" class="button">
					← <?php esc_html_e( 'Indietro', 'woo-legal-returns' ); ?>
				</a>
				<div class="wlr-actions-right">
					<a href="<?php echo esc_url( $this->wizard_url( 'checkout_notice' ) ); ?>" class="wlr-skip">
						<?php esc_html_e( 'Salta questo passaggio', 'woo-legal-returns' ); ?>
					</a>
					<button type="submit" class="button button-primary button-large">
						<?php esc_html_e( 'Avanti →', 'woo-legal-returns' ); ?>
					</button>
				</div>
			</div>
		</form>
		<?php
	}

	private function save_checkout_notice(): void {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Verified in handle_post before dispatch.
		$enabled = ! empty( $_POST['checkout_notice_enabled'] );
		$text    = wp_kses_post( wp_unslash( $_POST['checkout_notice_text'] ?? '' ) );
		// phpcs:enable WordPress.Security.NonceVerification.Missing
		$this->save_option( 'checkout_notice_enabled', $enabled );
		$this->save_option( 'checkout_notice_text', $text );
		$this->save_option( 'setup_complete', true );

		wp_safe_redirect( $this->wizard_url( 'complete' ) );
		exit;
	}

	private function render_step_checkout_notice(): void {
		$enabled  = (bool) $this->get_option( 'checkout_notice_enabled', true );
		$page_id  = (int) $this->get_option( 'precontractual_page_id' );
		$page_url = $page_id ? get_permalink( $page_id ) : '#';
		$default  = sprintf(
			/* translators: %1$d: giorni, %2$s: URL pagina informativa */
			__( 'Hai diritto di recedere dal contratto entro %1$d giorni senza fornire alcuna motivazione (art. 52 Cod. Consumo). <a href="%2$s">Maggiori informazioni</a>', 'woo-legal-returns' ),
			WLR_RETURN_DAYS,
			esc_url( $page_url )
		);
		if ( ! $page_id ) {
			$default = sprintf(
				/* translators: %d: giorni */
				__( 'Hai diritto di recedere dal contratto entro %d giorni senza fornire alcuna motivazione (art. 52 Cod. Consumo).', 'woo-legal-returns' ),
				WLR_RETURN_DAYS
			);
		}
		$text = (string) $this->get_option( 'checkout_notice_text', $default );
		?>
		<h2><?php esc_html_e( 'Avviso al Checkout', 'woo-legal-returns' ); ?></h2>
		<p class="wlr-step-desc">
			<?php esc_html_e( 'Visualizza un avviso informativo sul diritto di recesso nella pagina di checkout, prima del tasto di conferma ordine. Raccomandato per la conformità all\u2019art. 49 D.Lgs. 206/2005.', 'woo-legal-returns' ); ?>
		</p>

		<form method="post">
			<?php wp_nonce_field( 'wlr_wizard_checkout_notice' ); ?>
			<input type="hidden" name="wlr_wizard_step" value="checkout_notice">

			<div class="wlr-checkbox-group" style="margin-bottom:20px;">
				<label class="wlr-checkbox-label">
					<input type="checkbox" name="checkout_notice_enabled" value="1" <?php checked( $enabled ); ?>>
					<span>
						<strong><?php esc_html_e( 'Mostra avviso nella pagina di checkout', 'woo-legal-returns' ); ?></strong><br>
						<small><?php esc_html_e( 'Appare appena sopra il tasto "Conferma ordine"', 'woo-legal-returns' ); ?></small>
					</span>
				</label>
			</div>

			<div id="wlr-notice-fields">
				<table class="form-table" style="margin:0;">
					<tr>
						<th style="width:140px;"><?php esc_html_e( 'Testo avviso', 'woo-legal-returns' ); ?></th>
						<td>
							<textarea name="checkout_notice_text" rows="3" style="width:100%;max-width:500px;"><?php echo esc_textarea( $text ); ?></textarea>
							<p class="description"><?php esc_html_e( 'Puoi usare tag HTML di base (a, strong, em). Dopo aver associato la pagina informativa, verifica il link nel testo e salva l’avviso.', 'woo-legal-returns' ); ?></p>
						</td>
					</tr>
				</table>
			</div>

			<div class="wlr-wizard-actions">
				<a href="<?php echo esc_url( $this->wizard_url( 'menu' ) ); ?>" class="button">
					&larr; <?php esc_html_e( 'Indietro', 'woo-legal-returns' ); ?>
				</a>
				<div class="wlr-actions-right">
					<a href="<?php echo esc_url( $this->wizard_url( 'complete' ) ); ?>" class="wlr-skip">
						<?php esc_html_e( 'Salta questo passaggio', 'woo-legal-returns' ); ?>
					</a>
					<button type="submit" class="button button-primary button-large">
						<?php esc_html_e( 'Salva e Completa →', 'woo-legal-returns' ); ?>
					</button>
				</div>
			</div>
		</form>

		<script>
		jQuery( function ( $ ) {
			var $check = $( '[name="checkout_notice_enabled"]' );
			var $fields = $( '#wlr-notice-fields' );
			function sync() { $fields.toggle( $check.is( ':checked' ) ); }
			$check.on( 'change', sync );
			sync();
		} );
		</script>
		<?php
	}

	private function render_step_complete(): void {
		$this->save_option( 'setup_complete', true );
		$page_id = (int) $this->get_option( 'precontractual_page_id' );
		?>
		<div style="text-align:center;padding:20px 0 10px;">
			<div style="font-size:3rem;line-height:1;margin-bottom:16px;">✅</div>
			<h2 style="font-size:1.4rem;margin:0 0 12px;">
				<?php esc_html_e( 'Configurazione completata!', 'woo-legal-returns' ); ?>
			</h2>
			<p class="wlr-step-desc">
				<?php esc_html_e( 'Il plugin è operativo. Puoi rieseguire questa configurazione in qualsiasi momento dalla dashboard Resi UE.', 'woo-legal-returns' ); ?>
			</p>
			<?php if ( 'shortcode' === $this->get_option( 'precontractual_mode' ) ) : ?>
				<?php $this->render_policy_shortcode_instructions(); ?>
			<?php endif; ?>
			<div style="display:flex;gap:12px;justify-content:center;flex-wrap:wrap;margin-top:24px;">
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=wlr-returns' ) ); ?>"
					class="button button-primary button-large">
					<?php esc_html_e( 'Vai alla dashboard Resi', 'woo-legal-returns' ); ?>
				</a>
				<?php if ( $page_id ) : ?>
				<a href="<?php echo esc_url( get_edit_post_link( $page_id ) ); ?>"
					class="button button-large" target="_blank">
					<?php esc_html_e( 'Modifica pagina informativa', 'woo-legal-returns' ); ?>
				</a>
				<?php endif; ?>
			</div>
		</div>
		<?php
	}

	// -------------------------------------------------------------------------
	// Admin notice
	// -------------------------------------------------------------------------

	public function show_setup_notice(): void {
		if ( $this->get_option( 'setup_complete' ) ) {
			return;
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$screen = get_current_screen();
		if ( $screen && str_contains( $screen->id, self::WIZARD_SLUG ) ) {
			return;
		}
		?>
		<div class="notice notice-warning">
			<p>
				<strong><?php esc_html_e( 'Woo Legal Returns', 'woo-legal-returns' ); ?></strong>
				<?php esc_html_e( '— Configurazione iniziale non completata.', 'woo-legal-returns' ); ?>
				&nbsp;<a href="<?php echo esc_url( $this->wizard_url( 'precontractual' ) ); ?>" class="button button-small">
					<?php esc_html_e( 'Avvia configurazione guidata →', 'woo-legal-returns' ); ?>
				</a>
			</p>
		</div>
		<?php
	}

	// -------------------------------------------------------------------------
	// CSS
	// -------------------------------------------------------------------------

	private function render_styles(): void {
		?>
		<style>
		.wlr-wizard { max-width: 780px; }
		.wlr-wizard-title { margin-bottom: 24px !important; }
		.wlr-wizard-steps { display: flex; list-style: none; margin: 0 0 28px; padding: 0; counter-reset: step; gap: 0; }
		.wlr-wizard-steps li { flex: 1; text-align: center; font-size: .82rem; color: #a7aaad; padding-bottom: 14px; border-bottom: 3px solid #dcdcde; }
		.wlr-wizard-steps li::before { counter-increment: step; content: counter(step); display: block; width: 28px; height: 28px; line-height: 28px; border-radius: 50%; background: #dcdcde; color: #646970; font-weight: 700; margin: 0 auto 8px; font-size: .85rem; }
		.wlr-wizard-steps li.active { color: #2271b1; border-bottom-color: #2271b1; }
		.wlr-wizard-steps li.active::before { background: #2271b1; color: #fff; }
		.wlr-wizard-steps li.done { color: #1d8348; border-bottom-color: #1d8348; }
		.wlr-wizard-steps li.done::before { background: #1d8348; color: #fff; content: "✓"; }
		.wlr-wizard-card { background: #fff; border: 1px solid #c3c4c7; border-radius: 4px; padding: 32px 36px; }
		.wlr-wizard-card h2 { font-size: 1.15rem; margin: 0 0 8px; }
		.wlr-step-desc { color: #646970; margin: 0 0 24px; }
		.wlr-radio-group, .wlr-checkbox-group { display: flex; flex-direction: column; gap: 4px; }
		.wlr-radio-label, .wlr-checkbox-label { display: flex; align-items: flex-start; gap: 10px; padding: 12px 14px; border: 1px solid #dcdcde; border-radius: 4px; cursor: pointer; background: #fafafa; }
		.wlr-radio-label:hover, .wlr-checkbox-label:hover { background: #f0f6ff; border-color: #2271b1; }
		.wlr-radio-label input, .wlr-checkbox-label input { margin-top: 3px; flex-shrink: 0; }
		.wlr-sub-fields { margin: 0 0 12px 26px; padding: 12px 16px; background: #f8f8f8; border-radius: 4px; }
		.wlr-sub-fields label { display: block; font-weight: 600; margin-bottom: 6px; font-size: .85rem; }
		.wlr-info-box { background: #e8f4fd; border-left: 4px solid #2271b1; padding: 12px 16px; border-radius: 2px; margin-bottom: 20px; font-size: .875rem; }
		.wlr-wizard-actions { display: flex; justify-content: space-between; align-items: center; margin-top: 28px; padding-top: 20px; border-top: 1px solid #f0f0f1; }
		.wlr-actions-right { display: flex; align-items: center; gap: 12px; }
		.wlr-skip { color: #646970; font-size: .875rem; text-decoration: none; }
		.wlr-skip:hover { color: #2271b1; }
		</style>
		<?php
	}

	// -------------------------------------------------------------------------
	// Helpers
	// -------------------------------------------------------------------------

	public function wizard_url( string $step ): string {
		return admin_url( 'admin.php?page=' . self::WIZARD_SLUG . '&step=' . rawurlencode( $step ) );
	}

	private function render_policy_shortcode_instructions(): void {
		?>
		<p><code>[wlr_precontractual_policy]</code></p>
		<p><?php esc_html_e( 'Copia lo shortcode nel blocco Shortcode di WordPress o nel widget Shortcode di Elementor. Salva i dati venditore nel primo passaggio del wizard per aggiornare il testo dell’informativa.', 'woo-legal-returns' ); ?></p>
		<?php
	}

	public static function get_options(): array {
		return (array) get_option( self::OPTION_KEY, array() );
	}

	public function get_option( string $key, $fallback = null ): mixed {
		return self::get_options()[ $key ] ?? $fallback;
	}

	private function save_option( string $key, mixed $value ): void {
		$opts         = self::get_options();
		$opts[ $key ] = $value;
		update_option( self::OPTION_KEY, $opts );
	}

	private function sanitize_trader_data_from_post(): array {
		$defaults = $this->get_trader_data();

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Verified in handle_post before dispatch.
		$name    = sanitize_text_field( wp_unslash( $_POST['trader_name'] ?? $defaults['name'] ) );
		$address = sanitize_textarea_field( wp_unslash( $_POST['trader_address'] ?? $defaults['address'] ) );
		$email   = sanitize_email( wp_unslash( $_POST['trader_email'] ?? $defaults['email'] ) );
		$phone   = sanitize_text_field( wp_unslash( $_POST['trader_phone'] ?? $defaults['phone'] ) );
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		return array(
			'name'    => '' !== $name ? $name : $defaults['name'],
			'address' => '' !== $address ? $address : $defaults['address'],
			'email'   => '' !== $email ? $email : $defaults['email'],
			'phone'   => $phone,
		);
	}

	private function save_trader_data( array $trader_data ): void {
		foreach ( array( 'name', 'address', 'email', 'phone' ) as $key ) {
			$this->save_option( 'trader_' . $key, (string) ( $trader_data[ $key ] ?? '' ) );
		}
	}

	private function get_trader_data(): array {
		$defaults = $this->get_trader_defaults();
		$data     = array();

		foreach ( array( 'name', 'address', 'email', 'phone' ) as $key ) {
			$value        = (string) $this->get_option( 'trader_' . $key, '' );
			$data[ $key ] = '' !== $value ? $value : $defaults[ $key ];
		}

		return $data;
	}

	private function get_trader_defaults(): array {
		$name     = (string) get_bloginfo( 'name' );
		$addr1    = (string) get_option( 'woocommerce_store_address', '' );
		$addr2    = (string) get_option( 'woocommerce_store_address_2', '' );
		$city     = (string) get_option( 'woocommerce_store_city', '' );
		$postcode = (string) get_option( 'woocommerce_store_postcode', '' );
		$raw_cc   = (string) get_option( 'woocommerce_default_country', '' );
		$cc       = '' !== $raw_cc ? explode( ':', $raw_cc )[0] : '';
		$country  = $cc;

		if ( $cc && function_exists( 'WC' ) && WC() && WC()->countries ) {
			$countries = WC()->countries->get_countries();
			$country   = $countries[ $cc ] ?? $cc;
		}

		$email = (string) get_option( 'woocommerce_email_from_address', '' );
		$email = '' !== $email ? $email : (string) get_option( 'admin_email', '' );

		$address = implode(
			"\n",
			array_filter(
				array(
					$addr1,
					$addr2,
					trim( $postcode . ' ' . $city ),
					$country,
				)
			)
		);

		return array(
			'name'    => '' !== $name ? $name : '',
			'address' => $address,
			'email'   => $email,
			'phone'   => (string) get_option( 'woocommerce_store_phone', '' ),
		);
	}

	// -------------------------------------------------------------------------
	// Contenuto default pagina informativa
	// -------------------------------------------------------------------------

	private function get_default_page_content( ?array $trader_data = null ): string {
		if ( null === $trader_data ) {
			$trader_data = $this->get_trader_data();
		}
		$date    = esc_html( date_i18n( get_option( 'date_format' ) ) );
		$site    = esc_html( (string) ( $trader_data['name'] ?? get_bloginfo( 'name' ) ) );
		$address = (string) ( $trader_data['address'] ?? '' );
		$email   = sanitize_email( (string) ( $trader_data['email'] ?? '' ) );
		$phone   = sanitize_text_field( (string) ( $trader_data['phone'] ?? '' ) );

		$vendor_lines = array( '<strong>' . $site . '</strong>' );
		if ( '' !== $address ) {
			$vendor_lines[] = 'Sede legale: ' . nl2br( esc_html( $address ) );
		}
		if ( '' !== $email ) {
			$vendor_lines[] = 'Email: ' . WLR_Annex_Form::email_link( $email );
		}
		if ( '' !== $phone ) {
			$vendor_lines[] = 'Telefono: ' . WLR_Annex_Form::phone_link( $phone );
		}

		$vendor_block   = implode( "<br>\n", $vendor_lines );
		$address_inline = trim( preg_replace( '/\s+/', ' ', str_replace( array( "\r", "\n" ), ', ', $address ) ) );
		$email_item     = '' !== $email ? '<li>Inviando una dichiarazione scritta a: <strong>' . WLR_Annex_Form::email_link( $email ) . '</strong>;</li>' : '';
		$mail_item      = '' !== $address_inline ? '<li>Tramite raccomandata A/R a: <strong>' . esc_html( $address_inline ) . '</strong>.</li>' : '';

		return "<!-- wp:paragraph -->
<p><strong>Informativa sul Diritto di Recesso</strong><br>
Ai sensi degli artt. 49&#x2013;59 del D.Lgs. 206/2005 (Codice del Consumo), come modificato dal D.Lgs. 209/2025 (recepimento Direttiva UE 2023/2673)</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><strong>Venditore</strong></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>{$vendor_block}</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><strong>Diritto di recesso</strong></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Hai il diritto di recedere dal presente contratto entro <strong>14 giorni</strong> senza dover fornire alcuna motivazione.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Il periodo di recesso scade dopo 14 giorni dalla data in cui tu, o un terzo da te designato diverso dal vettore, entri in possesso fisico dei beni.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><strong>Come esercitare il diritto di recesso</strong></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Puoi inviare la richiesta direttamente dall'area cliente del sito. La procedura digitale registra la richiesta e invia una ricevuta via email.</p>
<!-- /wp:paragraph -->

<!-- wp:shortcode -->
[wlr_withdrawal_link label=\"Vai all'area Resi e Recesso\" class=\"\"]
<!-- /wp:shortcode -->

<!-- wp:list -->
<ul>
<li>Tramite la <strong>funzione digitale di recesso</strong> disponibile dal link sopra o dalla sezione Resi &amp; Recesso del tuo account;</li>
{$email_item}
{$mail_item}
</ul>
<!-- /wp:list -->

<!-- wp:paragraph -->
<p><strong>Effetti del recesso</strong></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Rimborseremo tutti i pagamenti ricevuti, compresi i costi di consegna standard, entro <strong>14 giorni</strong> dalla comunicazione di recesso, utilizzando lo stesso mezzo di pagamento usato per la transazione iniziale, salvo accordo diverso. Per i beni, salvo ritiro offerto dal venditore, possiamo trattenere il rimborso fino alla ricezione dei beni o della prova di spedizione, se precedente.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><strong>Restituzione dei beni</strong></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Dovrai restituire i beni all'indirizzo indicato dal venditore entro 14 giorni dalla comunicazione di recesso. I costi diretti di restituzione sono a tuo carico, salvo diversa indicazione.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><strong>Eccezioni al diritto di recesso (art. 59 D.Lgs. 206/2005)</strong></p>
<!-- /wp:paragraph -->

<!-- wp:list -->
<ul>
<li>Beni confezionati su misura o personalizzati;</li>
<li>Beni che rischiano di deteriorarsi o scadere rapidamente;</li>
<li>Beni sigillati aperti dopo la consegna non idonei alla restituzione per motivi igienici;</li>
<li>Contenuti digitali su supporto non materiale la cui esecuzione &egrave; iniziata con previo consenso espresso, riconoscimento della perdita del diritto e conferma su supporto durevole, nei casi previsti dalla normativa.</li>
</ul>
<!-- /wp:list -->

<!-- wp:shortcode -->
[wlr_model_withdrawal_form]
<!-- /wp:shortcode -->

<!-- wp:paragraph -->
<p><em>Aggiornato: {$date} &mdash; D.Lgs. 209/2025 (art. 54-bis Codice del Consumo)</em></p>
<!-- /wp:paragraph -->";
	}

	private function log_error( string $message ): void {
		if ( function_exists( 'wc_get_logger' ) ) {
			wc_get_logger()->error( $message, array( 'source' => 'woo-legal-returns' ) );
		}
	}
}
