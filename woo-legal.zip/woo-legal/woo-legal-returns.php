<?php
/**
 * Plugin Name:       Woo Legal Returns – EU Directive
 * Plugin URI:        https://github.com/marrisonlab/woo-legal
 * Description:       Adegua WooCommerce alla Direttiva UE sui Diritti dei Consumatori: modulo di recesso standardizzato, gestione richieste di reso nell'area cliente, notifiche email e dashboard admin.
 * Version:           1.5.6
 * Author:            Marrisonlab
 * Author URI:        https://marrisonlab.com
 * Text Domain:       woo-legal-returns
 * Domain Path:       /languages
 * Requires at least: 6.0
 * Requires PHP:      8.0
 * WC requires at least: 7.0
 * WC tested up to:   9.0
 * License:           GPL-2.0-or-later
 *
 * @package Woo_Legal_Returns
 */

defined( 'ABSPATH' ) || exit;

define( 'WLR_VERSION', '1.5.6' );
define( 'WLR_PLUGIN_FILE', __FILE__ );
define( 'WLR_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );
define( 'WLR_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'WLR_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'WLR_RETURN_DAYS', 14 ); // Diritto di recesso: 14 giorni.

/**
 * Verifica dipendenze prima di caricare il plugin.
 */
function wlr_check_requirements(): bool {
	return class_exists( 'WooCommerce' );
}

/**
 * Mostra avviso admin se WooCommerce non è attivo.
 */
function wlr_admin_notice_missing_woo(): void {
	echo '<div class="notice notice-error"><p>' .
		esc_html__( 'Woo Legal Returns richiede WooCommerce attivo.', 'woo-legal-returns' ) .
		'</p></div>';
}

/**
 * Inizializza il plugin.
 */
function wlr_init(): void {
	if ( ! wlr_check_requirements() ) {
		add_action( 'admin_notices', 'wlr_admin_notice_missing_woo' );
		return;
	}

	load_plugin_textdomain( 'woo-legal-returns', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );

	require_once WLR_PLUGIN_DIR . 'includes/class-wlr-lock.php';
	require_once WLR_PLUGIN_DIR . 'includes/class-wlr-post-type.php';
	require_once WLR_PLUGIN_DIR . 'includes/class-wlr-customer-account.php';
	require_once WLR_PLUGIN_DIR . 'includes/class-wlr-emails.php';
	require_once WLR_PLUGIN_DIR . 'includes/class-wlr-admin.php';
	require_once WLR_PLUGIN_DIR . 'includes/class-wlr-product-settings.php';
	require_once WLR_PLUGIN_DIR . 'includes/class-wlr-checkout-consent.php';
	require_once WLR_PLUGIN_DIR . 'includes/class-wlr-privacy.php';
	require_once WLR_PLUGIN_DIR . 'includes/class-wlr-annex-form.php';
	WLR_Post_Type::instance();
	WLR_Customer_Account::instance();
	WLR_Emails::instance();
	WLR_Admin::instance();
	WLR_Product_Settings::instance();
	WLR_Checkout_Consent::instance();
	WLR_Privacy::instance();
	WLR_Annex_Form::instance();

	// Il generatore dell'informativa serve anche allo shortcode pubblico.
	require_once WLR_PLUGIN_DIR . 'includes/class-wlr-setup-wizard.php';
	WLR_Setup_Wizard::instance();
}
add_action( 'plugins_loaded', 'wlr_init' );

/**
 * Aggiornamenti automatici da GitHub (non richiede WooCommerce).
 * I filtri vengono registrati subito, prima di qualsiasi hook,
 * per intercettare correttamente i controlli aggiornamenti via cron.
 */
require_once plugin_dir_path( __FILE__ ) . 'includes/class-wlr-github-updater.php';
( new WLR_GitHub_Updater() )->hooks();

/**
 * Attivazione: crea tabella personalizzata e flush rewrite rules.
 */
function wlr_activate(): void {
	require_once WLR_PLUGIN_DIR . 'includes/class-wlr-post-type.php';
	WLR_Post_Type::register_post_type();
	require_once WLR_PLUGIN_DIR . 'includes/class-wlr-customer-account.php';
	WLR_Customer_Account::instance()->add_endpoint();
	WLR_Customer_Account::ensure_withdrawal_page();
	flush_rewrite_rules();
}
register_activation_hook( __FILE__, 'wlr_activate' );

/**
 * Disattivazione.
 */
function wlr_deactivate(): void {
	wp_unschedule_hook( 'wlr_reject_late_returns' );
	flush_rewrite_rules();
}
register_deactivation_hook( __FILE__, 'wlr_deactivate' );

/**
 * Dichiarazione compatibilità HPOS (WooCommerce High-Performance Order Storage).
 */
add_action(
	'before_woocommerce_init',
	function (): void {
		if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
		}
	}
);
